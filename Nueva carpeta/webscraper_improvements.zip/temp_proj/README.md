# Web Scraper PRO – Extendido

Este fork amplía el **Web Scraper PRO** con mejoras centradas en la autonomía del agente, la usabilidad de la interfaz y la robustez de la base de datos.  Las funcionalidades existentes se mantienen, pero se han añadido nuevas capacidades para que el scraper sea más inteligente e independiente.

## Novedades Principales

* **Visualización y consulta de resultados:** la TUI ahora cuenta con una pestaña “Resultados” donde se listan las páginas procesadas.  Incluye un buscador para filtrar por dominio o título y botones para actualizar y exportar los datos.  Las exportaciones se generan en CSV o JSON dentro de la carpeta `scraper_exports` en el directorio de usuario.
* **Persistencia de estado de la TUI:** la configuración de la interfaz (URL inicial, concurrencia, opciones de robots y extracción LLM) se guarda de forma transparente en un archivo JSON.  Al volver a abrir la aplicación, se restauran los valores previos para ahorrar tiempo.
* **Robots.txt desactivado por defecto:** se invierte la lógica del argumento de línea de comandos.  El scraper ignora `robots.txt` de forma predeterminada para priorizar la profundidad del rastreo.  La opción `--respect-robots` permite habilitarlo cuando sea necesario.
* **Exportación JSON y búsqueda en la base de datos:** el `DatabaseManager` incorpora métodos para listar, buscar y exportar resultados a JSON, además de los CSV existentes.  La búsqueda facilita la creación de dashboards personalizados o la integración con otros sistemas.
* **Configuración mejorada de LLM:** se añade el parámetro `LLM_MODEL` en `settings.py` con un valor por defecto (`"gpt-3.5-turbo"`).  Esto soluciona errores cuando se invoca el extractor LLM sin definir explícitamente el modelo.

Estas mejoras cumplen con la hoja de ruta del archivo **MEJORAS.md** sin duplicar tareas ya contempladas en el **PLAN_DE_ACCION.MD**.  Se enfocan en dar mayor autonomía al scraper y mejorar la experiencia de usuario.

## Instrucciones de Uso

### Prerrequisitos

El proyecto requiere **Python 3.10** o superior.  Se recomienda crear un entorno virtual y usar los scripts incluidos para instalar las dependencias:

```bash
.\1-Install-Dependencies.bat
```

### Lanzar la aplicación

Para iniciar la interfaz textual (TUI) ejecuta:

```bash
.\2-Launch-Scraper.bat
```

Al arrancar verás las pestañas **Crawl**, **Estadísticas** y **Resultados**.  Introduce la URL de inicio y ajusta los parámetros como la concurrencia y el límite de páginas.  La opción **Ignorar robots.txt** está activada por defecto para permitir un rastreo agresivo.  Si deseas respetar las directrices de robots, marca la casilla.

### Ejecución por línea de comandos (CLI)

Para procesos automatizados puedes usar la CLI directamente:

```bash
.\.venv\Scripts\python.exe src/main.py --crawl https://ejemplo.com --concurrency 10 --export-json results.json
```

La CLI soporta las siguientes opciones clave:

| Parámetro                | Descripción                                                       |
|--------------------------|-------------------------------------------------------------------|
| `--respect-robots`       | Respeta las directrices de `robots.txt`.  Si se omite, se ignorarán.|
| `--llm`                  | Habilita la extracción con LLM usando el modelo definido en settings.|
| `--export-csv`           | Exporta la base de datos a un archivo CSV y sale.                |
| `--export-json`          | Exporta la base de datos a un archivo JSON y sale.               |

Consulta `python src/main.py --help` para ver todas las opciones disponibles.

## Flujo de Funcionamiento (Resumen)

El orquestador gestiona las URL en una cola priorizada.  Cada trabajador obtiene una URL, la precalifica con una petición `HEAD`, respeta o ignora `robots.txt` según la configuración y navega a la página usando Playwright con tácticas de evasión (rotación de user‑agents, fingerprinting y cookies persistentes).  El contenido extraído se limpia a través de un LLM y se guarda en la base de datos con un hash del contenido para evitar duplicados.  Luego se descubren nuevos enlaces para continuar el ciclo hasta que la cola esté vacía.

Con las mejoras añadidas, el ciclo de vida se enriquece con:

* **Consulta interactiva de resultados:** se puede revisar el contenido almacenado sin salir de la aplicación.  Esto elimina la necesidad de examinar la base de datos manualmente.
* **Persistencia de configuración:** la TUI recuerda tus preferencias de una sesión a otra.
* **Exportaciones enriquecidas:** además de CSV, puedes exportar datos a JSON para integrarlos con pipelines externos.

## Estructura del Proyecto (Actualizada)

El código fuente reside en la carpeta `src/`.

* `src/main.py`: Entrada principal de la aplicación.  Gestiona los argumentos de la CLI y arranca la TUI.  Incluye la opción `--respect-robots` y `--export-json` para los nuevos comportamientos.
* `src/tui.py`: Construye la interfaz textual.  Añade la pestaña **Resultados**, persistencia de estado, exportación, y corrige la inicialización del `LLMExtractor`.
* `src/database.py`: Gestiona la base de datos SQLite.  Añade métodos `list_results()`, `search_results(query)` y `export_to_json(file_path)` que permiten consultar y exportar datos de forma flexible.
* `src/settings.py`: Gestiona la configuración.  Ahora define el parámetro `LLM_MODEL` y sigue cargando las variables desde `.env` o entorno.
* Otros archivos (`orchestrator.py`, `scraper.py`, etc.) mantienen su papel original en el flujo de scraping y se benefician de las mejoras de base de datos y TUI.

Para más detalles sobre la arquitectura y funcionalidades avanzadas (agente de RL, extracción LLM, detección de duplicados, descubrimiento de APIs ocultas, etc.), consulta la documentación original en `README.md` y `MEJORAS.md`.

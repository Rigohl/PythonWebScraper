"""
Language model helper utilities.

This module exposes an ``LLMExtractor`` class that encapsulates calls to a
Large Language Model (LLM) for tasks such as cleaning HTML, extracting
structured data into Pydantic models and summarising long passages of text.
When the OpenAI API key is unavailable or when an API call fails, the
extractor falls back to simple deterministic logic so that the rest of
the pipeline can continue without throwing exceptions.  This design makes
the scraper resilient in offline environments and simplifies testing.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any, Type, TypeVar, Optional

try:
    import instructor
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except Exception:
    # If the OpenAI SDK or instructor is not installed, we mark the client as unavailable.
    OPENAI_AVAILABLE = False

from pydantic import BaseModel, create_model
from src.settings import settings

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


class LLMExtractor:
    """Wrapper around a Language Model for cleaning, extracting and summarising.

    Upon instantiation the extractor attempts to construct an OpenAI client
    patched by ``instructor``.  If the API key is not set or the required
    dependencies are missing, the extractor will operate in offline mode and
    rely on deterministic fallback logic.
    """

    def __init__(self) -> None:
        self.client: Optional[Any] = None
        if OPENAI_AVAILABLE and settings.LLM_API_KEY:
            try:
                self.client = instructor.patch(OpenAI(api_key=settings.LLM_API_KEY))
                logger.info("LLMExtractor inicializado con el cliente de OpenAI parcheado.")
            except Exception as e:
                logger.error(f"Error inicializando OpenAI client: {e}")
        else:
            logger.warning("LLM API no configurada o dependencias faltantes; se usará modo offline.")

    async def clean_text_content(self, text: str) -> str:
        """Clean HTML text using an LLM or fallback to naive heuristics.

        The cleaning prompt instructs the LLM to remove navigation bars,
        footers and other non‑essential elements.  If the call fails or
        offline mode is active, this method returns the original text.  For
        offline mode one could extend this with a simple readability filter.
        """
        if not self.client:
            # Fallback: no cleaning performed.
            return text
        try:
            class CleanedText(BaseModel):
                cleaned_text: str
            response = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                response_model=CleanedText,
                messages=[
                    {"role": "system", "content": "Eres un experto en limpiar contenido HTML. Tu tarea es eliminar todo el texto que no sea el contenido principal de la página, como barras de navegación, pies de página, anuncios, pop-ups y texto legal. Devuelve únicamente el contenido principal."},
                    {"role": "user", "content": text},
                ],
            )
            return response.cleaned_text
        except Exception as e:
            logger.error(f"Error durante la limpieza de texto con LLM: {e}", exc_info=True)
            return text

    async def extract_structured_data(self, html_content: str, response_model: Type[T]) -> T:
        """Perform zero‑shot extraction of structured data from HTML.

        When the LLM is unavailable this method returns an empty instance of
        ``response_model`` so that the caller can proceed without crashing.
        """
        if not self.client:
            return response_model()
        try:
            response = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                response_model=response_model,
                messages=[
                    {"role": "system", "content": "Eres un experto en extracción de datos de páginas web. Tu tarea es analizar el siguiente contenido HTML y rellenar el esquema Pydantic proporcionado con la información encontrada. Extrae los datos de la forma más precisa posible."},
                    {"role": "user", "content": html_content},
                ],
            )
            logger.info(f"Extracción Zero-Shot exitosa para el modelo {response_model.__name__}.")
            return response
        except Exception as e:
            logger.error(f"Error durante la extracción Zero-Shot con LLM: {e}", exc_info=True)
            return response_model()

    async def summarize_content(self, text_content: str, max_words: int = 100) -> str:
        """Summarise a block of text using the LLM or a naive fallback.

        If the LLM cannot be called, a simple heuristic summarisation is
        applied: the first ``max_words`` words of the input are returned.  In
        production one could replace this with a more sophisticated offline
        summariser such as a frequency‑based extractor.
        """
        if not self.client:
            # Naive summarisation: return the first ``max_words`` words.
            words = re.split(r"\s+", text_content)
            return " ".join(words[:max_words])
        try:
            response = await self.client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[
                    {"role": "system", "content": f"You are a helpful assistant. Summarize the following text in approximately {max_words} words."},
                    {"role": "user", "content": text_content},
                ],
                temperature=0.7,
                max_tokens=max_words * 2,
            )
            # The OpenAI API returns a list of choices; pick the first.
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error al sumarizar contenido con LLM: {e}", exc_info=True)
            return text_content[: max_words * 10]
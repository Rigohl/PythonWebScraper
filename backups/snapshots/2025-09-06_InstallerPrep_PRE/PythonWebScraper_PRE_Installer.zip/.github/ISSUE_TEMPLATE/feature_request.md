---
name: "✨ Solicitud de Mejora"
about: "Proponer nueva funcionalidad"
title: "[FEATURE]"
labels: ["type/feature","status/needs-triage"]
assignees: ""
---
## Propuesta
¿Qué quieres que exista y por qué?

## Contexto
Valor de negocio, usuarios impactados.

## Criterios de Aceptación
- [ ] Caso 1
- [ ] Caso 2

---
name: "🐛 Informe de Bug"
about: "Reportar un error o fallo"
title: "[BUG]"
labels: ["type/bug","status/needs-triage"]
assignees: ""
---
## Descripción
¿Qué pasó? ¿Qué esperabas?

## Reproducir
1. Paso
2. Paso
3. Resultado

## Evidencia
Logs, capturas, comandos.

## Impacto
(P0/P1/P2), área afectada.

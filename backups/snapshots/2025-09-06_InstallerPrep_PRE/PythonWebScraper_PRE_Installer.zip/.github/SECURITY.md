# Política de Seguridad
Si detectas una vulnerabilidad, envía reporte PRIVADO (no issues públicos):
- Correo: seguridad@example.com
Incluye: versión, pasos de repro, impacto y PoC si existe.